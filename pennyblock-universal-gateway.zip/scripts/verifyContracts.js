// Script to verify contracts
