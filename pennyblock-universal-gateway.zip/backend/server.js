// Backend server listens for payment and bridge events
