# Pennyblock W1 Blockchain — Project Overview & User Guide

## Introduction

Pennyblock is a custom, EVM-compatible Layer 2 blockchain designed to revolutionize token economics through a unique penny-stock style token model. The native token, **TOEKEN**, provides exponentially greater token rewards for smaller ETH deposits, encouraging micropayments, broad participation, and organic liquidity growth. Combined with a multi-chain universal payment gateway, anti-dump safeguards, and lazy NFT minting, Pennyblock offers a robust and user-friendly ecosystem for token holders, liquidity providers, and traders.

...

## Token Value Growth & Volatility Lock Impact (With Dollar Estimates)

Pennyblock’s design supports sustained token growth and liquidity by enforcing trading discipline and incentivizing steady profits.

- Starting with a **100-token share**, each token initially valued at **$0.01** (1 penny), the total starting value is **$1.00**.
- The token price appreciates by approximately **7% per volatility cycle**.
- Assume **4 trades per day**, each generating a 7% profit before hitting the anti-dump lock threshold.
- After each 7% increase, the system locks transfers until sufficient rebuying occurs, preventing price crashes and encouraging liquidity replenishment.

### Growth Projection with Dollar Values

| Time Frame | Token Amount (TOEKEN) | Approximate USD Value (@ token price)       |
|------------|----------------------|---------------------------------------------|
| 1 Day      | 131 tokens           | $1.31                                      |
| 1 Week     | 692 tokens           | $6.92                                      |
| 1 Month    | 3,043 tokens         | $30.43                                     |
| 1 Year     | 175,500 tokens       | $1,755                                     |
| 24 Years   | ~1.1 × 10^22 tokens  | ~$1.1 × 10^20 (100 quintillion USD)        |
| 50 Years   | ~1.3 × 10^44 tokens  | ~$1.3 × 10^42 (1.3 tredecillion USD)       |
| 100 Years  | ~1.8 × 10^88 tokens  | ~$1.8 × 10^86 (1.8 quindecillion USD)      |

...